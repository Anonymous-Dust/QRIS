const makeFile = require('./src/makeFile');
const makeString = require('./src/makeString');

module.exports = {
    makeFile,
    makeString
}