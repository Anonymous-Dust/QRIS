export { makeFile } from './src/makeFile';
export { makeString } from './src/makeString';